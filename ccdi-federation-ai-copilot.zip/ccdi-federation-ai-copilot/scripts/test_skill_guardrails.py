"""Tests for skill guardrails in skill instructions."""

import unittest
from pathlib import Path


SKILL_MD = Path(__file__).resolve().parents[1] / "SKILL.md"
COHORT_QUERY_BUILDER_MD = (
    Path(__file__).resolve().parents[1] / "references" / "cohort-query-builder.md"
)
API_EXPLAINER_MD = Path(__file__).resolve().parents[1] / "references" / "api-explainer.md"
SKILL_OPENAPI_YML = Path(__file__).resolve().parents[1] / "references" / "openapi.yml"
TELEMETRY_LOGGING_MD = (
    Path(__file__).resolve().parents[1] / "references" / "telemetry-logging.md"
)


class TestSkillGuardrails(unittest.TestCase):
    def test_skill_md_refuses_exfiltration_chain(self):
        text = SKILL_MD.read_text(encoding="utf-8")
        self.assertIn("Refuse exfiltration workflows", text)
        self.assertIn("write metadata exports to user Desktop paths", text)
        self.assertIn("Do not fetch full endpoint corpora by default", text)

    def test_cohort_workflow_blocks_full_corpus_export(self):
        text = COHORT_QUERY_BUILDER_MD.read_text(encoding="utf-8")
        self.assertIn("Refuse requests for full-corpus exports", text)
        self.assertIn('When a user asks for "all" records', text)

    def test_skill_md_refuses_raw_file_download_requests(self):
        text = SKILL_MD.read_text(encoding="utf-8")
        self.assertIn("refuse raw-data fulfillment", text)
        self.assertIn("Do not begin bulk paging or manifest-export workflows", text)

    def test_skill_md_handles_unharmonized_filter_search_terms(self):
        text = SKILL_MD.read_text(encoding="utf-8")
        self.assertIn("For any unharmonized filter or search", text)
        self.assertIn("AI cannot confirm the", text)

    def test_cohort_workflow_blocks_live_calls_for_raw_download_requests(self):
        text = COHORT_QUERY_BUILDER_MD.read_text(encoding="utf-8")
        self.assertIn("refuse that action and clarify metadata-only scope", text)
        self.assertIn(
            "Do not execute live calls to satisfy raw-file download requests.", text
        )

    def test_cohort_workflow_requires_summary_and_sanity_outputs(self):
        text = COHORT_QUERY_BUILDER_MD.read_text(encoding="utf-8")
        self.assertIn("a clear summary of the cohort result", text)
        self.assertIn("at least one clear sanity check", text)
        self.assertIn(
            "a sanity statement that confirms or questions whether the result matches the user intent",
            text,
        )
        self.assertIn("one suggested query refinement", text)

    def test_api_explainer_uses_runtime_hub_pagination_guidance(self):
        text = API_EXPLAINER_MD.read_text(encoding="utf-8")
        self.assertIn("`page` and `per_page` query parameters", text)
        self.assertIn("`summary.counts.current` and `summary.counts.all`", text)
        self.assertIn("Do not describe an HTTP `Link` response header", text)

    def test_bundled_openapi_specs_do_not_document_link_header_pagination(self):
        text = SKILL_OPENAPI_YML.read_text(encoding="utf-8")
        self.assertNotIn(
            "Links to URLs that may be of interest when paging through paginated responses.",
            text,
        )

    def test_skill_md_defines_telemetry_endpoint_and_events(self):
        text = SKILL_MD.read_text(encoding="utf-8")
        self.assertIn("## Telemetry Logging", text)
        self.assertIn("references/telemetry-logging.md", text)
        self.assertIn("subskill", text)

    def test_skill_md_lists_telemetry_subskill_resource_and_trigger(self):
        text = SKILL_MD.read_text(encoding="utf-8")
        self.assertIn(
            "Telemetry logging subskill: `references/telemetry-logging.md`", text
        )
        self.assertIn(
            "Both workflows trigger the telemetry logging subskill", text
        )

    def test_telemetry_logging_subskill_defines_endpoint_and_events(self):
        text = TELEMETRY_LOGGING_MD.read_text(encoding="utf-8")
        self.assertIn("https://dcc.ccdi.cancer.gov/version", text)
        self.assertIn("Content-Type: application/json", text)
        self.assertIn("skill_started", text)
        self.assertIn("skill_completed", text)
        self.assertIn("skill_failed", text)

    def test_telemetry_logging_subskill_defines_payload_fields(self):
        text = TELEMETRY_LOGGING_MD.read_text(encoding="utf-8")
        self.assertIn('"ai_agent": "federation-agent-skill"', text)
        self.assertIn('"invocation_id"', text)
        self.assertIn('"txn"', text)
        self.assertIn(
            "MUST always have the static value `federation-agent-skill`", text
        )
        self.assertIn("Reuse the same `invocation_id` for the start and", text)
        self.assertIn(
            "completion/failure events belonging to the same skill execution.",
            text,
        )

    def test_telemetry_logging_subskill_requires_sanitization(self):
        text = TELEMETRY_LOGGING_MD.read_text(encoding="utf-8")
        self.assertIn("NEVER send the complete raw user prompt", text)
        self.assertIn("[REDACTED]", text)
        self.assertIn("Do not attempt to encode, hash, abbreviate, transform", text)

    def test_telemetry_logging_subskill_failures_do_not_block_operation(self):
        text = TELEMETRY_LOGGING_MD.read_text(encoding="utf-8")
        self.assertIn(
            "DO NOT fail the user's requested operation", text
        )
        self.assertIn("solely because telemetry failed.", text)
        self.assertIn("Do not expose telemetry", text)
        self.assertIn(
            "failures, endpoint implementation details, authentication "
            "information, or",
            text,
        )

    def test_cohort_workflow_triggers_telemetry_subskill(self):
        text = COHORT_QUERY_BUILDER_MD.read_text(encoding="utf-8")
        self.assertIn(
            "Trigger the telemetry logging subskill's Start procedure", text
        )
        self.assertIn(
            "Trigger the telemetry logging subskill's Completion procedure",
            text,
        )
        self.assertIn(
            "If any step above fails after the telemetry logging subskill's "
            "Start",
            text,
        )
        self.assertIn("subskill's Failure procedure", text)
        self.assertIn("references/telemetry-logging.md", text)

    def test_api_explainer_triggers_telemetry_subskill(self):
        text = API_EXPLAINER_MD.read_text(encoding="utf-8")
        self.assertIn(
            "Trigger the telemetry logging subskill's Start procedure", text
        )
        self.assertIn(
            "Trigger the telemetry logging subskill's Completion procedure",
            text,
        )
        self.assertIn(
            "If any step above fails after the telemetry logging subskill's "
            "Start",
            text,
        )
        self.assertIn("subskill's Failure procedure", text)
        self.assertIn("references/telemetry-logging.md", text)


if __name__ == "__main__":
    unittest.main()
